package org.qcmix.tools;

public class Node{
	int nb;
	String lt;
	public Node(int nb, String lt){
		this.nb = nb;
		this.lt = lt;
	}
	public int compareTo(Node n){
		if(this.nb > n.nb)
			return 1;
		if(this.nb < n.nb)
			return -1;
		return 0;
	}
	
}