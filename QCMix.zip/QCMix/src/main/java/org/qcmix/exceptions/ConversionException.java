package org.qcmix.exceptions;

public class ConversionException extends Exception {

	private static final long serialVersionUID = -2192715088961590174L;

	public ConversionException(String message) {
		super(message);
	}
}
