package org.qcmix.exceptions;

public class ExternalCommandErrorException extends Exception {

	private static final long serialVersionUID = -8713862126663422281L;

	public ExternalCommandErrorException(String message) {
		super(message);
	}
}
