package org.qcmix;

import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.regex.Pattern;

import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.qcmix.exceptions.BadFormatException;
import org.qcmix.tools.Helper;

public class OdsTesteur {
	private static final int MAX_ROWS_IN_QCM = 1000;
	private static Vector<Integer> questionList = new Vector<>(MAX_ROWS_IN_QCM/4);
	private static int indiceR = 4;
	
	private static void addCaseToVerifieQuestionIndice(String s1, String s2, String s3){
		if(!s1.equals(""))
			questionList.add(Integer.parseInt(s1));
		if(!s2.equals(""))
			questionList.add(Integer.parseInt(s2));
		if(!s3.equals(""))
			questionList.add(Integer.parseInt(s3));
	}
	private static void verifieLettreSurLigne(boolean question, String cell1, String cell3, String cell5, int ligne) throws BadFormatException{
		if(! question){
			verifieLettre(cell1, ligne, 0);
			verifieLettre(cell3, ligne, 2);
			verifieLettre(cell5, ligne, 4);
		}
		indiceR++;

	}
	private static void verifieLettre(String cell,int ligne, int col) throws BadFormatException{
		if (Pattern.matches("[a-zA-Z]", cell)) {
			String text = "Le fichier contient une cellule inattendue:\nUne lettre a �t� trouv�e au mauvais endroit:\n "
					+ "ligne: " + Integer.toString(ligne + 1) + " - colonne: "+ col + " -> \"" + cell + "\"";
			throw new BadFormatException(text);
		}
	}
	
	private static void verifieNombreSurLigne(boolean question, String cell1, String cell3, String cell5, int ligne, Sheet sheet) throws BadFormatException{
		if(question){
			verifieNombre(cell1, ligne, 0, sheet);
			verifieNombre(cell3, ligne, 2, sheet);
			verifieNombre(cell5, ligne, 4, sheet);
			
		}
		else{
			if(Pattern.matches("\\d+",sheet.getCellAt(0, ligne + 1).getTextValue()))
				cell1 = "";
			
			if(Pattern.matches("\\d+",sheet.getCellAt(2, ligne + 1).getTextValue()))
				cell3 = "";
			
			if(Pattern.matches("\\d+",sheet.getCellAt(4, ligne + 1).getTextValue()))
				cell5 = "";
			addCaseToVerifieQuestionIndice(cell1, cell3, cell5);
		}
	}
	private static boolean verifieNombre(String cell, int ligne, int col, Sheet sheet) throws BadFormatException{
		boolean isRedactionPart = false;
		int nbInCell = -2;
		if(Pattern.matches("\\d+", cell))
			nbInCell = Integer.parseInt(cell);
		int nbInCellSuivante = -2;		
		if(Pattern.matches("\\d+",sheet.getCellAt(col, ligne + 1).getTextValue()))
			nbInCellSuivante = Integer.parseInt(sheet.getCellAt(col, ligne + 1).getTextValue());
		
			
		
		isRedactionPart = (nbInCell+1 == nbInCellSuivante) || sheet.getCellAt(col, ligne + 1).getTextValue().equals("");

		
		
		System.out.println("REDACTION "+isRedactionPart+ "Ligne" +ligne);
		
		
		if (! isRedactionPart) {
			String text = "Le fichier contient une cellule inattendue:\nUn chiffre a �t� trouv� au mauvais endroit:\n "
					+ "ligne: " + Integer.toString(ligne + 1) + " - colonne: "+ col + " -> \"" + cell + "\"";
			throw new BadFormatException(text);
		}
		return isRedactionPart;
	}
	private static void verifieListQuestion() throws BadFormatException{
		
		int indice = 1;
		boolean done = false;
		while(!questionList.isEmpty()){
			for(int i = 0; i < questionList.size(); i++){
				if(questionList.get(i) == indice){
					
					indice++;
					done = true;
					questionList.remove(i);
					break;
				}
			}
			if(!done){
				throw new BadFormatException("La question num�ro "+indice+" n'est pas renseign�e");
			}
			done = false;
		}
	}
	
	
	
	
	
	public static void checkSourceSheetFormat(File file) throws BadFormatException {
		
		Sheet sheet;
		
		// On charge le fichier, et on prend la première feuille de calcul
		try {
			sheet = SpreadSheet.createFromFile(file).getSheet(0);
			//checkSourceSheetFormat(sheet);
		}
		catch (NullPointerException | ClassCastException | IOException e) {
			throw new NullPointerException("Le fichier demand� n'est pas une feuille de calcul!\n\n" + Helper.getStackTrace(e));
		}
		
		
		int cpt_ligne = 0; // compteur de lignes du fichier ods
		//int indice_question = 0;
		boolean question = false; // boolean qui v�rifie si on est en cours de question

		//nombre de ligne de la feuille de calcul
		int rowCount  = sheet.getRowCount();

		//Tant qu'on a pas tout parcouru le fichier
		while(cpt_ligne < rowCount && cpt_ligne < MAX_ROWS_IN_QCM){
			
			String cell_text1 = sheet.getCellAt(0, cpt_ligne).getTextValue();
			String cell_text3 = sheet.getCellAt(2, cpt_ligne).getTextValue();
			String cell_text5 = sheet.getCellAt(4, cpt_ligne).getTextValue();
			// on v�rifie qu'il y a bien un espace entre chaque question/reponse et que les questions sont bien pr�c�d�es d'un chiffre
			if (Pattern.matches("\\d+", cell_text1)) {
				verifieNombreSurLigne(question, cell_text1, cell_text3, cell_text5, cpt_ligne, sheet);
				question = true;
				indiceR = 0;
			}
			
			// on v�rifie qu'une r�ponse a bien lieu apres les questions et que les r�ponses sont bien pr�c�d�es d'une lettre
			else if (Pattern.matches("[a-zA-Z]", cell_text1)) {

				verifieLettreSurLigne(question, cell_text1, cell_text3, cell_text5, cpt_ligne);
			}
			else if(cell_text1.equals("") || cell_text3.equals("") || cell_text5.equals("")) {
				if(question == true && cpt_ligne >2 && !Pattern.matches("\\d+",sheet.getCellAt(0, cpt_ligne-2).getTextValue())
					&& !Pattern.matches("\\d+",sheet.getCellAt(2, cpt_ligne-2).getTextValue())
					&& !Pattern.matches("\\d+",sheet.getCellAt(4, cpt_ligne-2).getTextValue())){
					if(indiceR > 4 ){
						String text = "Le fichier contient une cellule inattendue:\nUne lettre a �t� trouv� au mauvais endroit:\n "
								+ "ligne: " + Integer.toString(cpt_ligne + 1);
					
						throw new BadFormatException(text);
					}
					else if(indiceR < 4){
						String text = "Le fichier contient une cellule inattendue:\nUne question ne contient pas assez de r�ponses:\n "
								+ "ligne: " + Integer.toString(cpt_ligne+ 1);
					
						throw new BadFormatException(text);
					} 
				}
				question = false;	
			}
			//increment
			cpt_ligne++;
			
		}
		verifieListQuestion();
	}

}
