package org.qcmix.exceptions;

public class BadFormatException extends Exception {
	public BadFormatException() {
		super("Le format sp�cifi� est invalide");
	}
	
	public BadFormatException(String message) {
		super("Le format sp�cifi� est invalide: " + message);
	}

}
