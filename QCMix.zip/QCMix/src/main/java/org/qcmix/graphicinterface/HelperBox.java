package org.qcmix.graphicinterface;

import org.qcmix.tools.Helper;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class HelperBox {

	public static void helper() {
		
		String phrase_informations = "Les fichiers en entr�es doivent respecter les r�gles suivantes : \n\n"
				+ " - Format du fichier en entr�e : .ODS \n\n"
				+ " - Les lettres/chiffres doivent �tre plac�es sur les colonnes paires (0, 2 et 4) du fichier.\n\n"
				+ " - Les questions/r�ponses doivent �tre plac�es sur les colonnes impaires (1, 3 et 5) du fichier.\n\n"
				+ " - Les questions sont num�rot�es par des chiffres. \n\n"
				+ " - Les questions doivent avoir 4 r�ponses num�rot�es par des lettres. \n\n"
				+ " - Le fichier peut �ventuellement contenir un sujet d'expression �crite"
				+ " qui doit �tre plac� � la fin et il ne doit pas �tre num�rot�. \n "
				+ " - Les bonnes r�ponses doivent �tre sp�cifi� en couleur et NON en gras, italique ou soulign�\n\n";
		
		Window primaryStage = null;

		
		final Stage dialog = new Stage();
		dialog.initModality(Modality.APPLICATION_MODAL);
		dialog.initOwner(primaryStage);
		dialog.setTitle("Informations sur les fichiers d'entr�e ");

		
		Button infos2 = new Button();
		infos2.setText("Page Wiki ");
		infos2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Helper.openWebPage("https://framagit.org/wickedsnitch/QCMix2017/wikis/Structure-du-fichier");
			}
		});
		
		VBox dialogVbox = new VBox(20);		
		dialogVbox.getChildren().add(new Text(phrase_informations));
		dialogVbox.getChildren().add(infos2);
		dialogVbox.setPadding(new Insets(10));


		Scene dialogScene = new Scene(dialogVbox);
		
		
		dialog.setScene(dialogScene);
		dialog.show();

	}
	
}
